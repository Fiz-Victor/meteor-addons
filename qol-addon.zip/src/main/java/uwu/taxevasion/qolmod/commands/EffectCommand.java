package uwu.taxevasion.qolmod.commands;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.builder.LiteralArgumentBuilder;
import meteordevelopment.meteorclient.systems.commands.Command;
import meteordevelopment.meteorclient.systems.commands.Commands;
import net.minecraft.command.CommandSource;
import net.minecraft.command.argument.RegistryEntryArgumentType;
import net.minecraft.entity.effect.StatusEffect;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.nbt.StringNbtReader;
import net.minecraft.registry.RegistryKeys;
import net.minecraft.registry.entry.RegistryEntry;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import uwu.taxevasion.qolmod.Utils;

import static com.mojang.brigadier.Command.SINGLE_SUCCESS;

public class EffectCommand extends Command {
    public EffectCommand() {
        super("effect", "gives you a potion effect");
    }

    @Override
    public void build(LiteralArgumentBuilder<CommandSource> builder) {
        assert mc.interactionManager != null;
        assert mc.player != null;
        builder.then(argument("effect", RegistryEntryArgumentType.registryEntry(Commands.REGISTRY_ACCESS, RegistryKeys.STATUS_EFFECT))).then(argument("duration", IntegerArgumentType.integer()).then(argument("potency", IntegerArgumentType.integer()).executes(ctx -> {
            ItemStack bfr = mc.player.getMainHandStack();
            ItemStack egg = new ItemStack(Items.SALMON_SPAWN_EGG);
            BlockHitResult bhr = new BlockHitResult(mc.player.getEyePos(), Direction.DOWN, new BlockPos(mc.player.getEyePos()), false);
            int potency = ctx.getArgument("potency", Integer.class) - 1;
            RegistryEntry.Reference<StatusEffect> effect = ctx.getArgument("effect", RegistryEntry.Reference.class);
            info(effect.value().toString());
            egg.setNbt(StringNbtReader.parse("{EntityTag:{id:\"minecraft:area_effect_cloud\",Duration:2,Radius:2,WaitTime:0,Effects:[{Id:" + effect + ",Amplifier:" + potency + ",Duration:" + ctx.getArgument("duration", Integer.class) * 20 + "}]}}"));
            Utils.spawnItem(egg);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, bhr);
            Utils.spawnItem(bfr);
            return SINGLE_SUCCESS;
        })));
    }
}
