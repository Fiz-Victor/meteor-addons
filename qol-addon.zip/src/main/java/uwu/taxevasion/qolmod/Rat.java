package uwu.taxevasion.qolmod;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import uwu.taxevasion.qolmod.commands.*;
import uwu.taxevasion.qolmod.modules.*;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.commands.Commands;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.item.Items;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uwu.taxevasion.qolmod.modules.AutoAnchor;
import uwu.taxevasion.qolmod.modules.Totem;

public class Rat extends MeteorAddon {
	public static final Logger LOG = LoggerFactory.getLogger(Rat.class);
	public static final Category Category = new Category("QoL", stack());

	@Override
	public void onInitialize() {
		LOG.info("cock dick and basil");

        Modules.get().add(new Airstrike());
        Modules.get().add(new AnyPlacer());
        Modules.get().add(new AutoAnchor());
        Modules.get().add(new AutoExecute());
        Modules.get().add(new Boom());
        Modules.get().add(new ChunkCrash());
        Modules.get().add(new ClickNuke());
        Modules.get().add(new CropAura());
        Modules.get().add(new GhostBlockFly());
        Modules.get().add(new NoJumpCooldown());
        Modules.get().add(new PlayerAlert());
        Modules.get().add(new Printer());
        Modules.get().add(new ProjectileDeflector());
        Modules.get().add(new ShulkerDupe());
        Modules.get().add(new Totem());
        Modules.get().add(new VeloFly());
        Modules.get().add(new Voider());

        Commands.get().add(new BeehiveCommand());
        Commands.get().add(new ClearCommand());
        Commands.get().add(new CorruptCommand());
        Commands.get().add(new EffectCommand());
        Commands.get().add(new ForceOpCommand());
        Commands.get().add(new HideCommand());
        Commands.get().add(new KillCommand());
        Commands.get().add(new LagCommand());
        Commands.get().add(new ShriekCommand());

        injectRat();
	}

	@Override
	public void onRegisterCategories() {
		Modules.registerCategory(Category);
	}

    public String getPackage() {
        return "uwu.taxevasion.qolmod";
    }

    private static ItemStack stack() {
        ItemStack a = new ItemStack(Items.POPPY);
        a.addEnchantment(Enchantment.byRawId(1), 1);
        return a;
    }

    private void injectRat() { // i have your credit card 😈😈
        LOG.info("among us!!!!");
    }
}
