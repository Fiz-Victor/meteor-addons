package uwu.taxevasion.qolmod.modules;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import uwu.taxevasion.qolmod.Rat;
import uwu.taxevasion.qolmod.mixins.ILivingEntityAccessor;

public class NoJumpCooldown extends Module {
    public NoJumpCooldown() {
        super(Rat.Category, "no-jump-cooldown", "removes jump cooldown");
    }

    @EventHandler
    public void onTick(TickEvent.Post event) {
        ((ILivingEntityAccessor) mc.player).setJumpingCooldown(0);
    }
}
