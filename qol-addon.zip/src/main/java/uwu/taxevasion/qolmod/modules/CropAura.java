package uwu.taxevasion.qolmod.modules;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.*;
import net.minecraft.item.Item;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import uwu.taxevasion.qolmod.Rat;
import uwu.taxevasion.qolmod.Utils;

import java.util.List;

public class CropAura extends Module {
    private final SettingGroup sgPlant = settings.createGroup("Plant");
    private final SettingGroup sgHarvest = settings.createGroup("Harvest");

    // Planting
    private final Setting<List<Item>> plantlist = sgPlant.add(new ItemListSetting.Builder()
        .name("plant-list")
        .description("what to farm")
        .defaultValue(Items.CARROT, Items.BEETROOT_SEEDS, Items.WHEAT_SEEDS, Items.POTATO, Items.NETHER_WART)
        .filter(this::isPlant)
        .build());

    private final Setting<Integer> prange = sgPlant.add(new IntSetting.Builder()
        .name("plant-range")
        .description("range of planting")
        .defaultValue(2)
        .sliderRange(1, 6)
        .build());

    // Harvesting
    private final Setting<Integer> brange = sgHarvest.add(new IntSetting.Builder()
        .name("break-range")
        .description("range of breaking")
        .defaultValue(2)
        .sliderRange(1, 6)
        .build());

    public CropAura() {
        super(Rat.Category, "crop-aura", "ask for mushroom and i will disembowel you");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        for (int y = -1; y < 2; y++) {
            for (int x = -prange.get(); x <= prange.get(); x++) {
                for (int z = -prange.get(); z <= prange.get(); z++) {
                    BlockPos thepos = mc.player.getBlockPos().add(x, y, z);
                    tryPlant(thepos);
                }
            }
        }

        for (int y = -1; y < 2; y++) {
            for (int x = -brange.get(); x <= brange.get(); x++) {
                for (int z = -brange.get(); z <= brange.get(); z++) {
                    BlockPos thepos = mc.player.getBlockPos().add(x, y, z);
                    tryHarvest(thepos);
                }
            }
        }
    }

    private void tryPlant(BlockPos pos) {
        BlockHitResult bhr = new BlockHitResult(new Vec3d(pos.getX(), pos.getY(), pos.getZ()), Direction.UP, pos, false);
        if ((Utils.getBlock(pos) instanceof FarmlandBlock && Utils.getBlock(pos.up()) instanceof AirBlock && plantlist.get().contains(mc.player.getMainHandStack().getItem()) && !mc.player.getMainHandStack().isOf(Items.NETHER_WART))
            || (Utils.getBlock(pos) instanceof SoulSandBlock && mc.world.getBlockState(pos.up()).getBlock() instanceof AirBlock && mc.player.getMainHandStack().isOf(Items.NETHER_WART)))
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, bhr);
    }

    private void tryHarvest(BlockPos pos) { // how do i see if nether wart is mature :sob:
        if ((Utils.getBlock(pos) instanceof CropBlock && ((CropBlock) Utils.getBlock(pos)).isMature(mc.world.getBlockState(pos)))
         || (Utils.getBlock(pos) instanceof SugarCaneBlock && mc.world.getBlockState(pos.down()).getBlock() instanceof SugarCaneBlock))
            mc.interactionManager.attackBlock(pos, Utils.direction(mc.player.getYaw(0)));
    }

    private boolean isPlant(Item plant) {
        return plant == Items.CARROT || plant == Items.BEETROOT_SEEDS || plant == Items.MELON_SEEDS || plant == Items.PUMPKIN_SEEDS
            || plant == Items.WHEAT_SEEDS || plant == Items.POTATO || plant == Items.NETHER_WART;
    }
}
