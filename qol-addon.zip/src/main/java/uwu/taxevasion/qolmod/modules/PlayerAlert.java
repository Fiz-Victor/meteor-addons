package uwu.taxevasion.qolmod.modules;

import meteordevelopment.meteorclient.events.entity.EntityAddedEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.math.BlockPos;
import uwu.taxevasion.qolmod.Rat;

public class PlayerAlert extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> sound = sgGeneral.add(new BoolSetting.Builder()
        .name("play-sound")
        .description("Plays a sound when someone enters your render distance")
        .defaultValue(true)
        .build());

    public PlayerAlert() {
        super(Rat.Category, "player-alert", "Alerts you when a player enters your render distance");
    }

    @EventHandler
    private void onEntityAdded(EntityAddedEvent event) {
        if (!(event.entity instanceof PlayerEntity) || event.entity == mc.player) return;
        BlockPos pos = event.entity.getBlockPos();
        info(event.entity.getEntityName() + " is at " + pos.getX() + ", " + pos.getY() + ", " + pos.getZ());
        if (sound.get())
            mc.world.playSoundFromEntity(mc.player, mc.player, SoundEvents.ENTITY_PLAYER_LEVELUP, SoundCategory.PLAYERS, 2.0F, 1.0F);
    }
}
