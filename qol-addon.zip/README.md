# "How? How is the code so bad??" - you looking at src

<img width="450" src="https://cdn.discordapp.com/attachments/821798438819725393/1045759959222206534/download.jpeg">
<img src="https://img.shields.io/github/downloads/taxevasiqn/qol-addon/total?color=pink">
<img src="https://img.shields.io/github/languages/code-size/taxevasiqn/qol-addon">
<img src="https://img.shields.io/github/issues/taxevasiqn/qol-addon">
<img src="https://img.shields.io/github/stars/taxevasiqn/qol-addon?style=social">
<img src="https://img.shields.io/badge/license-DO%20NOT%20SKID-blue">

I have learnt from {addon which i will not name} that no matter how simplistic or bad an addon can be, cool design will get it lots of stars :)

### [Complain here](https://github.com/TaxEvasiqn/qol-addon/issues)
## Changelog

* Added crop aura (wip)
* Added player alert
* Made antikick work (blatant disinformation)
* Removed useless/bad modules & commands
* Projectile deflector has unshit itself
* Abbreviated code in some modules
* Added rats (they will spread bubonic plague into your pc)

### Module List
* Airstrike
* AnyPlacer
* Auto Anchor
* Auto Execute
* Boom
* Chunk Crash
* Click Nuke
* Crop Aura
* Ghost Block Fly (cope!!!!! you know who you are!!!!)
* No Jump Cooldown
* Player Alert
* Printer
* Projectile Deflector
* Shulker Dupe
* Instant Totem
* Velo Fly
* Voider

Buy me discord nitro `Tax Evasion²#1337` <3
