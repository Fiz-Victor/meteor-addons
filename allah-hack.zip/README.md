How?? how is the code so bad??? - you looking at src

yes i added ghost block fly cope!!!!
also maybe some skid idk i did most of this over a month ago
