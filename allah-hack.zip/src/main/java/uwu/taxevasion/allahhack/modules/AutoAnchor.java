package uwu.taxevasion.allahhack.modules;

import meteordevelopment.meteorclient.events.entity.player.PlaceBlockEvent;
import meteordevelopment.meteorclient.settings.IntSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.RespawnAnchorBlock;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.util.Hand;
import net.minecraft.util.hit.BlockHitResult;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Vec3d;
import uwu.taxevasion.allahhack.Allah;
import uwu.taxevasion.allahhack.Utils;

public class AutoAnchor extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> delay = sgGeneral.add(new IntSetting.Builder()
        .name("delay")
        .defaultValue(250)
        .sliderRange(50, 500)
        .build());

    public AutoAnchor() {
        super(Allah.Main, "auto-anchor", "kabooms an anchor after you place it");
    }

    @EventHandler
    private void onPlace(PlaceBlockEvent event) {
        if (!(event.block instanceof RespawnAnchorBlock)) return;
        BlockPos ppos = mc.player.getBlockPos();
        BlockPos bpos = event.blockPos;
        FindItemResult glowstone = InvUtils.findInHotbar(Items.GLOWSTONE);
        int prevSlot = mc.player.getInventory().selectedSlot;
        if (mc.player.isSneaking()) return;

        new Thread(() -> {
            Utils.sleep(delay.get() / 2);
            InvUtils.swap(glowstone.slot(), false);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(new Vec3d(bpos.getX(), bpos.getY(), bpos.getZ()), Direction.UP, bpos, false));
            InvUtils.swap(prevSlot, false);
            Utils.sleep(delay.get() / 2);
            mc.interactionManager.interactBlock(mc.player, Hand.MAIN_HAND, new BlockHitResult(new Vec3d(bpos.getX(), bpos.getY(), bpos.getZ()), Direction.UP, bpos, false));
        }).start();
    }

    boolean inRange(PlayerEntity player, BlockPos block) {
        BlockPos bpos = player.getBlockPos();
        if (block.getX() > bpos.getX() + 3.5 || block.getX() < bpos.getX() - 3.5)
            return false;

        if (block.getZ() > bpos.getZ() + 3.5 || block.getZ() < bpos.getZ() - 3.5)
            return false;

        if (block.getY() > bpos.getY() + 4.5 || block.getY() < bpos.getY() - 4.5)
            return false;

        else return true;
    }
}
