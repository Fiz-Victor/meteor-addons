package uwu.taxevasion.allahhack.modules;

import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.BoolSetting;
import meteordevelopment.meteorclient.settings.Setting;
import meteordevelopment.meteorclient.settings.SettingGroup;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.entity.Entity;
import net.minecraft.entity.projectile.FireballEntity;
import net.minecraft.entity.projectile.ShulkerBulletEntity;
import net.minecraft.util.math.Vec3d;
import net.minecraft.world.GameMode;
import uwu.taxevasion.allahhack.Allah;

public class ProjectileDeflector extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> velocheck = sgGeneral.add(new BoolSetting.Builder()
        .name("velocity-check")
        .description("Only attacks if the projectile is approaching.")
        .defaultValue(true)
        .build());

    public ProjectileDeflector() {
        super(Allah.Main, "projectile-deflector", "pasted!");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (!mc.player.isAlive() || mc.interactionManager.getCurrentGameMode() != GameMode.SPECTATOR) return;
        for (Entity entity : mc.world.getEntities()) {
            if (entity instanceof ShulkerBulletEntity || entity instanceof FireballEntity) {
                Entity proj = entity;
                if (inHitRange(mc.player, proj) && (isApproaching(mc.player.getPos(), proj.getPos(), proj.getVelocity())) || proj instanceof ShulkerBulletEntity) {
                    mc.interactionManager.attackEntity(mc.player, proj);
                }
            }
        }
    }

    boolean inHitRange(Entity attacker, Entity target) {
        return attacker.getCameraPosVec(1f).distanceTo(target.getPos().add(0, target.getHeight() / 2, 0)) <= mc.interactionManager.getReachDistance();
    }

    boolean isApproaching(Vec3d checkAgainst, Vec3d checkPos, Vec3d checkVel) {
        if (!(velocheck.get())) return true;
        return checkAgainst.distanceTo(checkPos) > checkAgainst.distanceTo(checkPos.add(checkVel));
    }
}
