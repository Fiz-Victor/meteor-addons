package uwu.taxevasion.allahhack;

import net.minecraft.enchantment.Enchantment;
import net.minecraft.item.ItemStack;
import uwu.taxevasion.allahhack.commands.*;
import uwu.taxevasion.allahhack.modules.*;
import meteordevelopment.meteorclient.addons.MeteorAddon;
import meteordevelopment.meteorclient.systems.commands.Commands;
import meteordevelopment.meteorclient.systems.modules.Category;
import meteordevelopment.meteorclient.systems.modules.Modules;
import net.minecraft.item.Items;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import uwu.taxevasion.allahhack.modules.AutoAnchor;
import uwu.taxevasion.allahhack.modules.Totem;

public class Allah extends MeteorAddon {
	public static final Logger LOG = LoggerFactory.getLogger(Allah.class);
	public static final Category Main = new Category("AllahHack", stack());

	@Override
	public void onInitialize() {
		LOG.info("summoning allah");

        Modules.get().add(new Airstrike());
        Modules.get().add(new AnyPlacer());
        Modules.get().add(new AutoAnchor());
        Modules.get().add(new AutoExecute());
        Modules.get().add(new BackTP());
        Modules.get().add(new Boom());
        Modules.get().add(new Bot());
        Modules.get().add(new ChunkCrash());
        Modules.get().add(new ClickNuke());
        Modules.get().add(new ConsoleFlood());
        Modules.get().add(new GhostBlockFly());
        Modules.get().add(new NoJumpCooldown());
        Modules.get().add(new Printer());
        Modules.get().add(new ProjectileDeflector());
        //Modules.get().add(new SexCrash());
        Modules.get().add(new ShulkerDupe());
        //Modules.get().add(new Test());
        Modules.get().add(new Totem());
        Modules.get().add(new VelocityBoost());
        Modules.get().add(new VeloFly());
        Modules.get().add(new Voider());
        Modules.get().add(new WorldGuardBypass());

        Commands.get().add(new BeehiveCommand());
        Commands.get().add(new BloatCommand());
        Commands.get().add(new ClearCommand());
        Commands.get().add(new CorruptCommand());
        Commands.get().add(new EffectCommand());
        Commands.get().add(new ForceOpCommand());
        Commands.get().add(new HideCommand());
        Commands.get().add(new KillCommand());
        Commands.get().add(new LagCommand());
        Commands.get().add(new RenameCommand());
        Commands.get().add(new ShriekCommand());
        Commands.get().add(new StopCommand());
	}

	@Override
	public void onRegisterCategories() {
		Modules.registerCategory(Main);
	}

    public String getPackage() {
        return "uwu.taxevasion.allahhack";
    }

    private static ItemStack stack() {
        ItemStack a = new ItemStack(Items.GLOW_LICHEN);
        a.addEnchantment(Enchantment.byRawId(1), 1);
        return a;
    }
}
